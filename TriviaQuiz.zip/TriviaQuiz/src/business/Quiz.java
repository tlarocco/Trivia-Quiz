
package business;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Ty Larocco
 */
public class Quiz {
    private String filename, errormsg;
    private int qNumber, qCount;
    private ArrayList<String> questions;
    private ArrayList<String> answers;
    private boolean over;
    
    public Quiz(String path) {
        this.errormsg = "";
        this.filename = path;
        questions = new ArrayList<>();
        answers = new ArrayList<>();
        this.qNumber = 0;
        this.qCount = 0;
        this.over = true;
        
        try {
            BufferedReader in = new BufferedReader(new FileReader(path));
            String s = in.readLine();
            while (s != null) {
                this.questions.add(s);
                this.answers.add(in.readLine());
                this.qCount++;
                s = in.readLine();
            }
            in.close();
        } catch (IOException e) {
            this.errormsg = "File " + path + " not found.";
            this.over = true;
            this.qCount = 0;
        } catch (Exception e) {
            this.errormsg = "Constructor failure: " + e.getMessage();
            this.over = true;
            this.qCount = 0;
        }
        if (this.qCount == 0) {
            this.errormsg = "This Quiz file had no questions.";
            
        } else {
            this.over = false;
            this.qNumber =1;
        }
        
    }//end of contrustor
    
    public String getErrorMsg() {
        return this.errormsg;
    }
    
    public int getQCount() {
        return this.qCount;
    }
    
    public boolean isOver() {
        return this.over;
    }
    
    public int getQNumber() {
        return this.qNumber;
    }
    
    public String getAnswer() {
        if (this.over || this.qNumber > this.qCount) {
            this.over = true;
            return "Answer requested on finished quiz.";
        }
        String a = this.answers.get(this.qNumber-1);
        this.qNumber++;
        if (this.qNumber > this.qCount) {
            this.over = true;
        }
        return a;
    }
    
    public String getQuestion() {
        if (this.over) {
            return "That's all folks.";
        } 
        return this.questions.get(this.qNumber-1);    
        
    }
}
